#!/usr/bin/env bash
set -e

# Configuration
OWNER="asjura"
REPO="web3-ghostwriting-mastery"
BRANCH="main"
COMMIT_MSG="chore: add static dashboard + GitHub Pages workflow"

echo "Checking for gh (GitHub CLI)..."
if ! command -v gh >/dev/null 2>&1; then
  echo "gh is required. Install it (https://cli.github.com/) and run 'gh auth login', then re-run this script."
  exit 1
fi

# Create repo if it doesn't exist
if gh repo view "$OWNER/$REPO" >/dev/null 2>&1; then
  echo "Repository $OWNER/$REPO already exists. Will push to it."
else
  echo "Creating repository $OWNER/$REPO..."
  gh repo create "$OWNER/$REPO" --public --source=. --remote=origin --push || {
    echo "Failed to create repo via gh. You can create it manually and re-run this script."
    exit 1
  }
  echo "Repository created and initial push performed by gh."
  exit 0
fi

# If repo exists, push manually
git init >/dev/null 2>&1 || true
git add .
git commit -m "$COMMIT_MSG" || true
git branch -M $BRANCH || true
git remote remove origin 2>/dev/null || true
git remote add origin "git@github.com:${OWNER}/${REPO}.git"
git push -u origin $BRANCH --force

echo "Pushed to ${OWNER}/${REPO} on branch ${BRANCH}. Check Actions tab for the Pages deployment workflow."